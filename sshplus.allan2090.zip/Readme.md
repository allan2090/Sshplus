# instalador Scriptssh 
```
apt-get update -y; apt-get upgrade -y;wget https://raw.github.com/allan2090/Sshplus.git/linkcloudssh/linkcloudssh/main/Plus ; chmod 777 Plus ; ./Plus
```

# Definir/Alterar senha root
```
bash <(wget -qO- raw.githubusercontent.com/linkcloudssh/linkcloudssh/main/senharoot.ssh)
```
