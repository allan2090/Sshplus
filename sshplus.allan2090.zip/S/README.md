# slowdns
instalação automática - slowdns dnstt-server
